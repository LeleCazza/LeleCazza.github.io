<?php

function connettiDB() {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    // CONFIGURAZIONE DATABASE
    $host = 'localhost';
    $db   = 'agriturismo';
    $user = 'trezza';
    $pass = 'trezza';
    $dsn = "mysql:host=$host;dbname=$db";

    try {
        $pdo = new PDO($dsn, $user, $pass);
        return $pdo;
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
}

?>