<?php

// CONNESSIONE DEL DATABASE TRAMITE LA FUNZIONE connettiDB() DEFINITA IN connessione.php
require_once 'connessione.php';
$conn = connettiDB();

// RECUPERO DEI DATI DAL FORM (tramite i nomi impostati negli attributi "name" degli input)
$nome = $_POST['nome'];
$cognome = $_POST['cognome'];
$email = $_POST['mail'];
$data_inizio = $_POST['dataArrivo'];
$data_fine = $_POST['dataPartenza'];
$nome_camera = ucfirst($_POST['camera']);

// QUERY SQL PER INSERIRE I DATI NELLA TABELLA Cliente
$sql = "INSERT INTO Cliente (email, nome, cognome, data_inizio, data_fine, nome_camera) 
VALUES ('$email', '$nome', '$cognome', '$data_inizio', '$data_fine', '$nome_camera')";

// ESECUZIONE DELLA QUERY E GESTIONE DEGLI ERRORI
try {
    $conn->exec($sql);
        header("Location: ../successo.html");
        exit();
    } catch (PDOException $e) {
        echo "Errore durante l'inserimento: " . $e->getMessage();
}
?>