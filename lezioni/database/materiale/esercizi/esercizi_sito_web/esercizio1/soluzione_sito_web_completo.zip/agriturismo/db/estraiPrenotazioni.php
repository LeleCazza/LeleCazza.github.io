<?php

// CONNESSIONE DEL DATABASE TRAMITE LA FUNZIONE connettiDB() DEFINITA IN connessione.php
require_once 'connessione.php';
$conn = connettiDB();

// QUERY SQL PER SELEZIONARE TUTTI I DATI DALLA TABELLA Cliente
$sql = "SELECT * FROM Cliente";
$stmt = $conn->query($sql);

// STAMPA DELL'INTESTAZIONE DELLA TABELLA HTML
$clienti = $stmt->fetchAll(PDO::FETCH_ASSOC);
if (!$clienti) {
    echo "<p class='w3-container w3-bold'>Non ci sono prenotazioni registrate.</p>";
}
else{
    echo "<table border='1' class='w3-table-all w3-card-4 w3-hoverable '>
            <tr class='w3-khaki'>
                <th class='w3-center'>Nome</th>
                <th class='w3-center'>Cognome</th>
                <th class='w3-center'>Email</th>
                <th class='w3-center'>Arrivo</th>
                <th class='w3-center'>Partenza</th>
                <th class='w3-center'>Camera</th>
            </tr>";

    // CICLO PER STAMPARE I RISULTATI DELLA QUERY IN UNA TABELLA HTML
    foreach ($clienti as $row) {
        echo "<tr>";
        echo "<td class='w3-center'>" . htmlspecialchars($row['nome']) . "</td>";
        echo "<td class='w3-center'>" . htmlspecialchars($row['cognome']) . "</td>";
        echo "<td class='w3-center'>" . $row['email'] . "</td>";
        echo "<td class='w3-center'>" . $row['data_inizio'] . "</td>";
        echo "<td class='w3-center'>" . $row['data_fine'] . "</td>";
        echo "<td class='w3-center'>" . $row['nome_camera'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>