CREATE DATABASE IF NOT EXISTS agriturismo;

USE agriturismo;

CREATE TABLE IF NOT EXISTS Camera (
    nome VARCHAR(50) PRIMARY KEY,
    prezzo FLOAT NOT NULL
);

CREATE TABLE IF NOT EXISTS Cliente (
    email VARCHAR(100) PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL,
    data_inizio DATE NOT NULL,
    data_fine DATE NOT NULL,
    nome_camera VARCHAR(50) NOT NULL,
    FOREIGN KEY (nome_camera) REFERENCES Camera(nome)
);

INSERT INTO Camera (nome, prezzo) VALUES ('Lavanda', 40.00), ('Farina', 50.00), ('Uva', 60.00);

-- TRUNCATE TABLE Cliente;